# Customer Feedback Sentiment Analyzer — Flask + NLP

This portfolio project is a small web app that ingests customer feedback (CSV), performs sentiment analysis, and visualizes results.

## Stack
- Python, Flask
- TextBlob for sentiment (with a simple built-in fallback)
- SQLite
- Bootstrap + Chart.js

## Features
- Upload CSV of feedback (`feedback_text` column required)
- Auto-classifies comments as Positive / Neutral / Negative
- Stores results in SQLite
- Dashboard with doughnut chart of sentiment distribution

## Quickstart
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
# Open http://127.0.0.1:5000
```
Optionally test with the included `sample_feedback.csv`.

## Resume bullet
Built a Flask-based web app for sentiment analysis of customer feedback, integrating TextBlob NLP and Chart.js visualizations, enabling automated sentiment classification and interactive reporting.


from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3, os, csv, io
from datetime import datetime
from contextlib import closing

# Optional: use TextBlob if installed; otherwise fallback to a simple heuristic
try:
    from textblob import TextBlob
    USE_TEXTBLOB = True
except Exception:
    USE_TEXTBLOB = False

DB_PATH = os.path.join(os.path.dirname(__file__), 'feedback.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with closing(get_db()) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                polarity REAL NOT NULL,
                subjectivity REAL NOT NULL,
                label TEXT NOT NULL,
                channel TEXT,
                customer_id TEXT,
                created_at TEXT NOT NULL
            );
        ''')
        conn.commit()

def classify(text):
    if USE_TEXTBLOB:
        tb = TextBlob(text)
        polarity = float(tb.sentiment.polarity)
        subjectivity = float(tb.sentiment.subjectivity)
    else:
        # Simple fallback heuristic
        positive_words = ['love','great','amazing','good','fast','clean','helpful','quick','exactly','thanks','value']
        negative_words = ['terrible','crashing','damaged','slow','confusing','frustrating','failed','bad']
        text_l = text.lower()
        score = sum(w in text_l for w in positive_words) - sum(w in text_l for w in negative_words)
        polarity = max(-1.0, min(1.0, score / 3.0))
        subjectivity = 0.5
    label = 'Positive' if polarity > 0.1 else ('Negative' if polarity < -0.1 else 'Neutral')
    return polarity, subjectivity, label

def insert_feedback(rows):
    with closing(get_db()) as conn:
        conn.executemany('''
            INSERT INTO feedback(text, polarity, subjectivity, label, channel, customer_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', rows)
        conn.commit()

def fetch_summary():
    with closing(get_db()) as conn:
        cur = conn.execute('SELECT label, COUNT(*) as cnt FROM feedback GROUP BY label')
        counts = {r['label']: r['cnt'] for r in cur.fetchall()}
        total = sum(counts.values()) or 0
        cur2 = conn.execute('SELECT COUNT(*) as n FROM feedback')
        n = cur2.fetchone()['n']
        return counts, total, n

app = Flask(__name__)
app.secret_key = 'dev-secret'  # replace in production

@app.route('/', methods=['GET'])
def index():
    init_db()
    counts, total, n = fetch_summary()
    return render_template('index.html', counts=counts, total=total, n=n)

@app.route('/upload', methods=['POST'])
def upload():
    init_db()
    file = request.files.get('file')
    if not file or not file.filename.endswith(('.csv','.txt')):
        flash('Please upload a CSV file.')
        return redirect(url_for('index'))
    data = file.read().decode('utf-8', errors='ignore')
    reader = csv.DictReader(io.StringIO(data))
    rows = []
    now = datetime.utcnow().isoformat()
    for r in reader:
        text = (r.get('feedback_text') or r.get('text') or '').strip()
        if not text:
            continue
        channel = r.get('channel') or ''
        customer_id = r.get('customer_id') or ''
        polarity, subj, label = classify(text)
        rows.append((text, polarity, subj, label, channel, customer_id, now))
    if not rows:
        flash('No valid feedback rows found. Ensure your CSV has a "feedback_text" column.')
        return redirect(url_for('index'))
    insert_feedback(rows)
    flash(f'Uploaded and analyzed {len(rows)} feedback entries.')
    return redirect(url_for('index'))

@app.route('/reset', methods=['POST'])
def reset():
    with closing(get_db()) as conn:
        conn.execute('DELETE FROM feedback')
        conn.commit()
    flash('Database cleared.')
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)


import os, io, csv, sqlite3
from datetime import datetime
from contextlib import closing
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file, jsonify
from dotenv import load_dotenv

# NLP imports (with graceful fallbacks)
USE_TEXTBLOB, USE_VADER = False, False
try:
    from textblob import TextBlob
    USE_TEXTBLOB = True
except Exception:
    pass
try:
    import nltk
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    try:
        # Ensure lexicon exists
        nltk.data.find('sentiment/vader_lexicon.zip')
    except LookupError:
        nltk.download('vader_lexicon')
    VADER = SentimentIntensityAnalyzer()
    USE_VADER = True
except Exception:
    VADER = None

DB_PATH = os.path.join(os.path.dirname(__file__), 'feedback.db')
load_dotenv()
SECRET_KEY = os.getenv('FLASK_SECRET', 'dev-secret')
ADMIN_USER = os.getenv('ADMIN_USER', 'admin')
ADMIN_PASS = os.getenv('ADMIN_PASS', 'password123')

app = Flask(__name__)
app.secret_key = SECRET_KEY

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with closing(get_db()) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                polarity REAL,
                subjectivity REAL,
                label TEXT,
                model TEXT,
                channel TEXT,
                customer_id TEXT,
                created_at TEXT NOT NULL
            )
        ''')
        conn.commit()

def classify_textblob(text):
    tb = TextBlob(text)
    pol = float(tb.sentiment.polarity)
    subj = float(tb.sentiment.subjectivity)
    label = 'Positive' if pol > 0.1 else ('Negative' if pol < -0.1 else 'Neutral')
    return pol, subj, label

def classify_vader(text):
    scores = VADER.polarity_scores(text)
    comp = scores['compound']
    label = 'Positive' if comp > 0.05 else ('Negative' if comp < -0.05 else 'Neutral')
    return comp, 0.0, label

def classify(text, model='vader'):
    if model == 'textblob' and USE_TEXTBLOB:
        return classify_textblob(text) + ('textblob',)
    if model == 'vader' and USE_VADER:
        pol, subj, label = classify_vader(text)
        return pol, subj, label, 'vader'
    # Fallback heuristic
    positive_words = ['love','great','amazing','good','fast','clean','helpful','quick','exactly','thanks','value','friendly','awesome']
    negative_words = ['terrible','crashing','damaged','slow','confusing','frustrating','failed','bad','broken','late','bug','issue']
    t = text.lower()
    score = sum(w in t for w in positive_words) - sum(w in t for w in negative_words)
    pol = max(-1.0, min(1.0, score/3.0))
    label = 'Positive' if pol > 0.1 else ('Negative' if pol < -0.1 else 'Neutral')
    return pol, 0.5, label, 'heuristic'

def insert_feedback(rows):
    with closing(get_db()) as conn:
        conn.executemany('''
            INSERT INTO feedback(text, polarity, subjectivity, label, model, channel, customer_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', rows)
        conn.commit()

def fetch_counts(model=None, q=None, flabel=None, dfrom=None, dto=None):
    where = []
    params = []
    if model:
        where.append("model = ?"); params.append(model)
    if q:
        where.append("LOWER(text) LIKE ?"); params.append('%'+q.lower()+'%')
    if flabel:
        where.append("label = ?"); params.append(flabel)
    if dfrom:
        where.append("created_at >= ?"); params.append(dfrom)
    if dto:
        where.append("created_at <= ?"); params.append(dto)
    sql = "SELECT label, COUNT(*) cnt FROM feedback"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " GROUP BY label"
    with closing(get_db()) as conn:
        cur = conn.execute(sql, params)
        counts = {r['label']: r['cnt'] for r in cur.fetchall()}
    return counts

def fetch_samples(limit=10, order='desc'):
    order_sql = "DESC" if order.lower() == 'desc' else "ASC"
    with closing(get_db()) as conn:
        cur = conn.execute(f"SELECT text, label, model, created_at FROM feedback ORDER BY id {order_sql} LIMIT ?", (limit,))
        return cur.fetchall()

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            flash('Please log in to access that page.')
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('username')
        pw = request.form.get('password')
        if user == ADMIN_USER and pw == ADMIN_PASS:
            session['logged_in'] = True
            flash('Logged in.')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials.')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.')
    return redirect(url_for('login'))

@app.route('/')
def home():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    init_db()
    q = request.args.get('q') or None
    flabel = request.args.get('label') or None
    dfrom = request.args.get('from') or None
    dto = request.args.get('to') or None
    model = request.args.get('model') or None
    counts = fetch_counts(model=model, q=q, flabel=flabel, dfrom=dfrom, dto=dto)
    total = sum(counts.values()) if counts else 0
    samples = fetch_samples()
    return render_template('index.html', counts=counts, total=total, samples=samples, model=model or 'all')

@app.route('/upload', methods=['POST'])
@login_required
def upload():
    init_db()
    file = request.files.get('file')
    model = request.form.get('model') or 'vader'
    if not file or not file.filename.endswith(('.csv','.txt')):
        flash('Please upload a CSV.')
        return redirect(url_for('dashboard'))
    data = file.read().decode('utf-8', errors='ignore')
    reader = csv.DictReader(io.StringIO(data))
    rows = []
    now = datetime.utcnow().isoformat()
    for r in reader:
        text = (r.get('feedback_text') or r.get('text') or '').strip()
        if not text:
            continue
        channel = r.get('channel') or ''
        customer_id = r.get('customer_id') or ''
        pol, subj, label, used = classify(text, model=model)
        rows.append((text, float(pol), float(subj), label, used, channel, customer_id, now))
    if not rows:
        flash('No valid rows found. Column "feedback_text" is required.')
        return redirect(url_for('dashboard'))
    insert_feedback(rows)
    flash(f'Uploaded and analyzed {len(rows)} feedback entries using {rows[0][4].upper()}.')
    return redirect(url_for('dashboard'))

@app.route('/reset', methods=['POST'])
@login_required
def reset():
    with closing(get_db()) as conn:
        conn.execute('DELETE FROM feedback')
        conn.commit()
    flash('Database cleared.')
    return redirect(url_for('dashboard'))

@app.route('/report.csv')
@login_required
def report_csv():
    with closing(get_db()) as conn:
        cur = conn.execute('SELECT text, polarity, subjectivity, label, model, channel, customer_id, created_at FROM feedback ORDER BY id DESC')
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([c[0] for c in cur.description])
        for row in cur.fetchall():
            writer.writerow(row)
        mem = io.BytesIO(output.getvalue().encode('utf-8'))
        mem.seek(0)
        return send_file(mem, mimetype='text/csv', as_attachment=True, download_name='sentiment_report.csv')

@app.route('/evaluate')
@login_required
def evaluate():
    # Evaluate both models if available using labeled data
    labeled_path = os.path.join(os.path.dirname(__file__), 'data', 'labeled_feedback.csv')
    gold = []
    import csv as _csv
    with open(labeled_path, newline='', encoding='utf-8') as f:
        for r in _csv.DictReader(f):
            gold.append((r['feedback_text'], r['label']))
    def pred(text, model):
        pol, subj, lab, used = classify(text, model=model)
        return lab
    models = []
    if USE_TEXTBLOB: models.append('textblob')
    if USE_VADER: models.append('vader')
    if not models: models.append('heuristic')
    results = {}
    labels = ['Positive','Neutral','Negative']
    for m in models:
        cm = {a:{b:0 for b in labels} for a in labels}
        correct = 0
        for text, true in gold:
            p = pred(text, m)
            if p == true: correct += 1
            cm[true][p] += 1
        acc = correct/len(gold)
        results[m] = {'confusion': cm, 'accuracy': acc}
    return jsonify(results)

if __name__ == '__main__':
    init_db()
    # Demo mode: preload sample if empty
    with closing(get_db()) as conn:
        cur = conn.execute('SELECT COUNT(*) FROM feedback')
        if cur.fetchone()[0] == 0:
            try:
                import csv as _csv
                sample_path = os.path.join(os.path.dirname(__file__), 'data', 'sample_feedback.csv')
                now = datetime.utcnow().isoformat()
                rows = []
                with open(sample_path, newline='', encoding='utf-8') as f:
                    for r in _csv.DictReader(f):
                        text = r['feedback_text']
                        pol, subj, lab, model = classify(text, 'vader')
                        rows.append((text, pol, subj, lab, model, r.get('channel',''), r.get('customer_id',''), now))
                insert_feedback(rows)
                print('Sample data loaded.')
            except Exception as e:
                print('Sample preload failed:', e)
    app.run(host='0.0.0.0', port=5000, debug=True)

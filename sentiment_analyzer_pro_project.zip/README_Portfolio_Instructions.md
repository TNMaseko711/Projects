# Customer Feedback Sentiment Analyzer — Pro (Flask + NLP)

A portfolio-ready web app that ingests customer feedback, performs sentiment analysis using **VADER** and **TextBlob** (with a safe fallback), stores results in SQLite, and visualizes them with Chart.js. Includes CSV export, simple authentication, evaluation with a labeled set, Docker support, and cloud deployment notes.

## Features
- CSV upload → sentiment classification (Positive / Neutral / Negative)
- Choose NLP model: VADER or TextBlob (fallback heuristic if packages missing)
- SQLite storage
- Dashboard + doughnut chart
- **/report.csv** export
- **Authentication** (session-based) with `.env` credentials
- **Evaluation** endpoint `/evaluate` returns accuracy + confusion matrix
- **Docker** and **Procfile** for container/cloud
- **Demo mode**: auto-loads sample data if DB is empty

## Quickstart (Local)
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python app.py
# Open http://127.0.0.1:5000 (login with ADMIN_USER/ADMIN_PASS from .env)
```

## Docker
```bash
docker compose up --build
# Open http://localhost:8000
```

## Render/Heroku-style Deploy
- Add environment variables: `FLASK_SECRET`, `ADMIN_USER`, `ADMIN_PASS`
- Use `Procfile` and set the start command to `gunicorn app:app` (Render automatically detects Python)

## Resume Bullet
Built a Flask-based web app for sentiment analysis with VADER/TextBlob, added CSV export and authentication, evaluation against a labeled set, and Docker/Render deploy scripts for a production-like demo.

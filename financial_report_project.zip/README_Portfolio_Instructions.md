# Automated Financial Report — Excel & Python

**Overview**  
Python-powered automation pipeline that aggregates monthly financial data, calculates profit, and outputs a fully formatted Excel report with pivot tables and charts.

**Tech Stack**
- Python (Pandas, NumPy, Matplotlib, XlsxWriter)
- Excel

**Features**
- Reads raw CSV/Excel financial transactions
- Aggregates by month, department, and category
- Calculates profit automatically
- Outputs styled Excel file ready for stakeholders
- Reduces manual data entry by ~40%

**How to Run**
1. Place `financial_data.csv` in the project folder.
2. Run `python generate_financial_report.py`.
3. Open `automated_financial_report.xlsx` to view results.

**Sample Output**
![Monthly Profit](monthly_profit_chart.png)

**Portfolio Bullet**
Automated monthly financial reporting pipeline using Python (Pandas, NumPy) and Excel, reducing manual data entry by ~40% and improving accuracy through programmatic aggregation and formatting.

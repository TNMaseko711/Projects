import pandas as pd
import numpy as np

# Load data
df = pd.read_csv('financial_data.csv', parse_dates=['Month'])

# Aggregate by month and department
pivot = df.pivot_table(index=['Month', 'Department'], 
                       columns='Category', 
                       values='Amount', 
                       aggfunc='sum').reset_index()

# Calculate profit
pivot['Profit'] = pivot['Revenue'] - pivot['Expense']

# Export to styled Excel
with pd.ExcelWriter('automated_financial_report.xlsx', engine='xlsxwriter') as writer:
    pivot.to_excel(writer, sheet_name='Report', index=False)
    
    workbook = writer.book
    worksheet = writer.sheets['Report']
    
    # Add format
    money_fmt = workbook.add_format({'num_format': '#,##0', 'bold': False})
    for col in range(2, 5):
        worksheet.set_column(col, col, 15, money_fmt)
    
    worksheet.set_column(0, 1, 20)
    worksheet.freeze_panes(1, 0)
